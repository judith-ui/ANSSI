# Projet ANSSI CVE

Analyse des avis et alertes ANSSI avec enrichissement des CVE (MITRE + EPSS).

## Objectifs

1. Extraire les flux RSS des avis et alertes ANSSI.
2. Identifier les CVE mentionnées dans les bulletins.
3. Enrichir les CVE avec les API MITRE et EPSS.
4. Consolider les données dans un DataFrame pandas puis dans un fichier CSV.
5. Réaliser des visualisations et une analyse exploratoire (notebook).
6. Ajouter un modèle Machine Learning supervisé et un modèle non supervisé.
7. Générer des alertes personnalisées par email.

## Installation

```bash
python -m venv .venv
source .venv/bin/activate   # Mac/Linux
# .venv\Scripts\activate    # Windows
pip install -r requirements.txt
```

## Structure

```
ANSSI/
├── data/
│   ├── raw/                  # données brutes éventuelles
│   ├── processed/            # fichiers intermédiaires (bulletins_cves.csv, enrichissement_cves.csv)
│   ├── final/                # CSV et Excel consolidés finaux
│   └── local/                # données pré-téléchargées (mode local)
│       ├── avis/             # JSON des avis ANSSI (un fichier par bulletin, nommé CERTFR-…)
│       ├── alertes/          # JSON des alertes ANSSI
│       ├── mitre/            # réponses JSON de l'API MITRE (un fichier par CVE)
│       └── first/            # réponses JSON de l'API EPSS FIRST (un fichier par CVE)
├── notebooks/
│   └── analyse_anssi.ipynb   # notebook d'analyse, visualisation et ML
├── src/
│   ├── config.py             # chemins, URLs, constantes, mode local
│   ├── extract_rss.py        # étape 1 : extraction des flux RSS
│   ├── extract_cve.py        # étape 2 : extraction des CVE depuis les JSON ANSSI
│   ├── enrich_mitre.py       # étape 3a : enrichissement MITRE (CVSS, CWE, produits)
│   ├── enrich_epss.py        # étape 3b : enrichissement EPSS FIRST
│   ├── build_dataset.py      # étape 4 : pipeline complet → CSV + Excel
│   ├── alerts.py             # étape 7 : génération des alertes email
│   └── local_loader.py       # utilitaires de lecture des fichiers locaux
├── outputs/
│   ├── figures/              # graphiques exportés par le notebook
│   └── emails/               # emails d'alerte générés
├── requirements.txt
└── README.md
```

## Lancer la génération du CSV

Depuis le dossier `src/` :

```bash
cd src

# Test rapide : 3 bulletins, 10 CVE enrichies
python build_dataset.py --max-bulletins 3 --max-cves 10

# Production : tous les bulletins
python build_dataset.py --max-bulletins -1

# Sans enrichissement (CSV de base rapide)
python build_dataset.py --max-bulletins 5 --skip-enrichment
```

Le CSV sera créé dans `data/final/donnees_anssi_cve_enrichies.csv`.
Le fichier Excel sera créé dans `data/final/donnees_anssi_cve_enrichies.xlsx`.

## Mode données locales

Pour éviter des requêtes répétées vers les API pendant le développement :

1. Placer les fichiers JSON dans les dossiers `data/local/avis/`, `data/local/alertes/`,
   `data/local/mitre/`, `data/local/first/` (nommés par ID bulletin ou CVE).
2. Dans `src/config.py`, passer `USE_LOCAL_DATA = True`.
3. Lancer le pipeline normalement — aucune requête réseau ne sera effectuée.

## Lancer les alertes

Après création du CSV :

```bash
cd src
python alerts.py
```

Les fichiers email seront créés dans `outputs/emails/`.

## Notebook d'analyse

```bash
jupyter notebook notebooks/analyse_anssi.ipynb
```

Le notebook couvre :
- Exploration du DataFrame
- Visualisations (CVSS, EPSS, CWE, éditeurs, temporalité…)
- Modèle ML non supervisé (clustering)
- Modèle ML supervisé (classification criticité)
- Validation des modèles

## Paramètres de rate limiting

Le code inclut un délai de `REQUEST_DELAY_SECONDS` (défaut : 2 s) entre chaque
requête API pour limiter la charge sur les serveurs externes.
Ce délai est désactivé automatiquement en mode local.
