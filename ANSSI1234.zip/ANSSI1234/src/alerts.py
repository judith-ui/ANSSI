"""Génération d'alertes personnalisées à partir du CSV final."""

import sys
import pandas as pd

from config import EMAILS_DIR, FINAL_CSV_PATH

PRODUITS_SURVEILLES = ["Apache", "Microsoft", "Cisco", "Ivanti", "Linux", "Windows"]
CVSS_THRESHOLD = 9.0
EPSS_THRESHOLD = 0.70


def create_email_alert(row: pd.Series) -> tuple[str, str]:
    """Crée le sujet et le corps d'un email d'alerte."""
    subject = f"Alerte CVE critique : {row.get('cve', 'CVE inconnue')}"

    body = f"""Bonjour,

Une vulnérabilité prioritaire a été détectée dans les données ANSSI.

CVE : {row.get('cve')}
Bulletin ANSSI : {row.get('id_anssi')}
Type de bulletin : {row.get('type_bulletin')}
Date de publication : {row.get('date_publication')}

Éditeur : {row.get('vendor')}
Produit : {row.get('product')}
Versions affectées : {row.get('versions_affectees')}

Score CVSS : {row.get('cvss_score')}
Niveau CVSS : {row.get('niveau_cvss')}
Score EPSS : {row.get('epss_score')}
CWE : {row.get('cwe')}

Description :
{row.get('description_cve')}

Lien ANSSI :
{row.get('lien_anssi')}

Action recommandée :
Vérifier si le produit et la version sont utilisés dans votre environnement,
puis appliquer les correctifs ou mesures de contournement recommandés par
l'éditeur et l'ANSSI.

Cordialement,
Système de veille CVE
"""
    return subject, body


def generate_alerts() -> pd.DataFrame:
    """Filtre les CVE prioritaires et génère des fichiers texte d'alerte."""

    # Vérifie que le CSV final existe
    if not FINAL_CSV_PATH.exists():
        print(
            f"Erreur : le fichier CSV final est introuvable ({FINAL_CSV_PATH}).\n"
            "Lancez d'abord : python src/build_dataset.py"
        )
        sys.exit(1)

    EMAILS_DIR.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(FINAL_CSV_PATH)

    # Normalisation des noms de colonnes (majuscule → minuscule avec underscore)
    col_map = {
        "ID ANSSI": "id_anssi",
        "Titre ANSSI": "titre_anssi",
        "Type": "type_bulletin",
        "Date": "date_publication",
        "Lien": "lien_anssi",
        "CVE": "cve",
        "Description": "description_cve",
        "CWE": "cwe",
        "CVSS": "cvss_score",
        "EPSS": "epss_score",
        "Niveau CVSS": "niveau_cvss",
        "Éditeur": "vendor",
        "Produit": "product",
        "Versions affectées": "versions_affectees",
    }
    df = df.rename(columns={k: v for k, v in col_map.items() if k in df.columns})

    product_pattern = "|".join(PRODUITS_SURVEILLES)
    product_matches = df["product"].fillna("").str.contains(product_pattern, case=False, regex=True)

    priority = (
        (df["cvss_score"].fillna(0) >= CVSS_THRESHOLD)
        | (df["epss_score"].fillna(0) >= EPSS_THRESHOLD)
    )
    df_alerts = df[priority & product_matches].copy()

    generated = 0
    for _, row in df_alerts.iterrows():
        subject, body = create_email_alert(row)
        cve_safe = str(row.get("cve", "UNKNOWN")).replace("/", "_")
        output_path = EMAILS_DIR / f"alerte_{cve_safe}.txt"
        with open(output_path, "w", encoding="utf-8") as file:
            file.write(subject + "\n\n" + body)
        generated += 1

    print(f"Nombre d'alertes générées : {generated}")
    print(f"Dossier : {EMAILS_DIR}")
    return df_alerts


if __name__ == "__main__":
    generate_alerts()
