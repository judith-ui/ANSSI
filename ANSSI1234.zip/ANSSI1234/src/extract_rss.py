# Étape 1 : Extraction des Flux RSS ANSSI

import feedparser
import pandas as pd
import requests

from config import RSS_AVIS_URL, RSS_ALERTES_URL, REQUEST_TIMEOUT, USE_LOCAL_DATA
from local_loader import list_local_bulletins, load_local_bulletin


def extract_rss_feed(url: str, bulletin_type: str, verbose: bool = False) -> pd.DataFrame:
    """Extrait les données d'un flux RSS ANSSI."""

    headers = {"User-Agent": "Mozilla/5.0"}

    try:
        response = requests.get(url, headers=headers, timeout=REQUEST_TIMEOUT)
        response.raise_for_status()
        feed = feedparser.parse(response.content)

        if verbose:
            print(f"{bulletin_type} récupérés : {len(feed.entries)}")

    except Exception as exc:
        print(f"Erreur RSS {bulletin_type} : {exc}")
        return pd.DataFrame()

    rows = []
    for entry in feed.entries:
        rows.append(
            {
                "titre_anssi": entry.get("title", ""),
                "description_anssi": entry.get("description", ""),
                "date_publication": entry.get("published", ""),
                "lien_anssi": entry.get("link", ""),
                "type_bulletin": bulletin_type,
            }
        )

    return pd.DataFrame(rows)


def extract_all_rss_local(verbose: bool = False) -> pd.DataFrame:
    """
    Construit la liste des bulletins depuis les fichiers locaux pré-téléchargés.
    Utilisé quand USE_LOCAL_DATA=True.
    """
    ids = list_local_bulletins()

    if verbose:
        print(f"Bulletins locaux trouvés : {len(ids)}")

    rows = []
    for bulletin_id in ids:
        data = load_local_bulletin(bulletin_id)
        if data is None:
            continue

        # Détermine le type depuis l'ID (AVI = avis, ALE = alerte)
        if "-AVI-" in bulletin_id:
            bulletin_type = "Avis"
            lien = f"https://www.cert.ssi.gouv.fr/avis/{bulletin_id}/"
        else:
            bulletin_type = "Alerte"
            lien = f"https://www.cert.ssi.gouv.fr/alerte/{bulletin_id}/"

        rows.append(
            {
                "titre_anssi": data.get("title", bulletin_id),
                "description_anssi": data.get("description", ""),
                "date_publication": data.get("date_public", ""),
                "lien_anssi": lien,
                "type_bulletin": bulletin_type,
            }
        )

    return pd.DataFrame(rows)


def extract_all_rss(verbose: bool = False) -> pd.DataFrame:
    """Extrait les avis et alertes ANSSI (mode local ou API RSS)."""

    if USE_LOCAL_DATA:
        return extract_all_rss_local(verbose=verbose)

    df_avis = extract_rss_feed(RSS_AVIS_URL, "Avis", verbose=verbose)
    df_alertes = extract_rss_feed(RSS_ALERTES_URL, "Alerte", verbose=verbose)

    return pd.concat([df_avis, df_alertes], ignore_index=True)


if __name__ == "__main__":
    df = extract_all_rss(verbose=True)
    print(df.head())
    print(f"Nombre total de bulletins : {len(df)}")
