# Étape 2 : Extraction des CVE depuis les JSON ANSSI

import re
import time
from typing import Any

import requests

from config import REQUEST_DELAY_SECONDS, REQUEST_TIMEOUT, USE_LOCAL_DATA
from local_loader import load_local_bulletin

CVE_PATTERN = r"CVE-\d{4}-\d{4,7}"


def get_json_url(lien_anssi: str) -> str:
    """Construit l'URL JSON d'un bulletin ANSSI."""
    if not lien_anssi:
        return ""
    lien_anssi = lien_anssi.strip()
    if lien_anssi.endswith("/"):
        return lien_anssi + "json/"
    return lien_anssi + "/json/"


def fetch_bulletin_json(lien_anssi: str) -> dict[str, Any] | None:
    """
    Télécharge le JSON d'un bulletin ANSSI.
    Si USE_LOCAL_DATA est activé, charge depuis les fichiers locaux.
    """
    # Extraction de l'ID CERTFR depuis l'URL (ex: CERTFR-2024-ALE-001)
    match = re.search(r"CERTFR-\d{4}-(?:AVI|ALE)-\d+", lien_anssi)
    bulletin_id = match.group(0) if match else None

    if USE_LOCAL_DATA:
        if bulletin_id:
            return load_local_bulletin(bulletin_id)
        print(f"Impossible d'extraire l'ID CERTFR depuis : {lien_anssi}")
        return None

    url_json = get_json_url(lien_anssi)
    if not url_json:
        return None

    try:
        response = requests.get(url_json, timeout=REQUEST_TIMEOUT)
        response.raise_for_status()
        return response.json()

    except Exception as exc:
        print(f"Erreur JSON ANSSI pour {url_json}: {exc}")
        return None

    finally:
        time.sleep(REQUEST_DELAY_SECONDS)


def extract_cves_from_json(data: dict[str, Any] | None) -> list[str]:
    """
    Extrait les CVE présentes dans un JSON ANSSI.

    Méthode prioritaire :
    - clé officielle 'cves' du JSON ANSSI (liste de dicts {name, url}).

    Méthode de secours :
    - regex sur le JSON complet si la clé 'cves' est absente ou vide.
    """
    if data is None:
        return []

    cves = set()

    # Méthode 1 : clé officielle ANSSI
    official_cves = data.get("cves", [])
    for item in official_cves:
        if isinstance(item, dict):
            name = item.get("name")
            if isinstance(name, str) and re.fullmatch(CVE_PATTERN, name):
                cves.add(name)
        elif isinstance(item, str) and re.fullmatch(CVE_PATTERN, item):
            cves.add(item)

    # Méthode 2 : regex de secours si la clé officielle ne donne rien
    if not cves:
        cves.update(re.findall(CVE_PATTERN, str(data)))

    return sorted(cves)
