# Étape 3 : Enrichissement des CVE via l'API MITRE

import time
from typing import Any

import requests

from config import REQUEST_DELAY_SECONDS, REQUEST_TIMEOUT, USE_LOCAL_DATA
from local_loader import load_local_mitre


def extract_cvss_metrics(metrics: list[dict[str, Any]]) -> dict[str, Any]:
    """
    Extrait les informations CVSS détaillées.
    Gère plusieurs versions : CVSS v4.0, v3.1, v3.0, v2.0.
    """
    result = {
        "cvss_score": None,
        "base_severity": None,
        "cvss_version": None,
        "cvss_vector": None,
        "attack_vector": None,
        "attack_complexity": None,
        "privileges_required": None,
        "user_interaction": None,
        "scope": None,
        "confidentiality_impact": None,
        "integrity_impact": None,
        "availability_impact": None,
    }

    cvss_keys = ["cvssV4_0", "cvssV3_1", "cvssV3_0", "cvssV2_0"]

    for metric in metrics:
        for key in cvss_keys:
            if key in metric:
                cvss = metric[key]
                result["cvss_score"] = cvss.get("baseScore")
                result["base_severity"] = cvss.get("baseSeverity")
                result["cvss_version"] = key.replace("cvssV", "").replace("_", ".")
                result["cvss_vector"] = cvss.get("vectorString")
                result["attack_vector"] = cvss.get("attackVector")
                result["attack_complexity"] = cvss.get("attackComplexity")
                result["privileges_required"] = cvss.get("privilegesRequired")
                result["user_interaction"] = cvss.get("userInteraction")
                result["scope"] = cvss.get("scope")
                result["confidentiality_impact"] = cvss.get("confidentialityImpact")
                result["integrity_impact"] = cvss.get("integrityImpact")
                result["availability_impact"] = cvss.get("availabilityImpact")
                return result

    return result


def enrich_cve_mitre(cve_id: str) -> dict[str, Any]:
    """Enrichit une CVE avec les données MITRE (local ou API)."""

    result = {
        "cve": cve_id,
        "description_cve": None,
        "cvss_score": None,
        "base_severity": None,
        "cvss_version": None,
        "cvss_vector": None,
        "attack_vector": None,
        "attack_complexity": None,
        "privileges_required": None,
        "user_interaction": None,
        "scope": None,
        "confidentiality_impact": None,
        "integrity_impact": None,
        "availability_impact": None,
        "cwe": None,
        "cwe_description": None,
        "vendor": None,
        "product": None,
        "versions_affectees": None,
    }

    try:
        # --- Chargement des données (local ou API) ---
        if USE_LOCAL_DATA:
            data = load_local_mitre(cve_id)
            if data is None:
                return result
        else:
            url = f"https://cveawg.mitre.org/api/cve/{cve_id}"
            response = requests.get(url, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            data = response.json()

        cna = data.get("containers", {}).get("cna", {})

        # Description
        descriptions = cna.get("descriptions", [])
        if descriptions:
            result["description_cve"] = descriptions[0].get("value")

        # CVSS détaillé
        metrics = cna.get("metrics", [])
        cvss_info = extract_cvss_metrics(metrics)
        result.update(cvss_info)

        # CWE
        problem_types = cna.get("problemTypes", [])
        if problem_types:
            descriptions_pt = problem_types[0].get("descriptions", [])
            if descriptions_pt:
                result["cwe"] = descriptions_pt[0].get("cweId")
                result["cwe_description"] = descriptions_pt[0].get("description")

        # Produits affectés
        affected = cna.get("affected", [])
        vendors, products, versions = [], [], []

        for item in affected:
            vendor = item.get("vendor")
            product = item.get("product")
            if vendor:
                vendors.append(vendor)
            if product:
                products.append(product)
            for version in item.get("versions", []):
                if version.get("status") == "affected":
                    version_value = version.get("version")
                    if version_value:
                        versions.append(version_value)

        result["vendor"] = ", ".join(sorted(set(vendors))) if vendors else None
        result["product"] = ", ".join(sorted(set(products))) if products else None
        result["versions_affectees"] = ", ".join(sorted(set(versions))) if versions else None

    except Exception as exc:
        print(f"Erreur MITRE pour {cve_id}: {exc}")

    finally:
        # Délai uniquement en mode API pour ne pas ralentir les lectures locales
        if not USE_LOCAL_DATA:
            time.sleep(REQUEST_DELAY_SECONDS)

    return result
