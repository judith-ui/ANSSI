# Étape 4 : Consolidation des données ANSSI + CVE + enrichissement MITRE/EPSS

import argparse
import re
from urllib.parse import urlparse

import pandas as pd

from config import FINAL_CSV_PATH, FINAL_DIR, PROCESSED_DIR
from enrich_epss import enrich_cve_epss
from enrich_mitre import enrich_cve_mitre
from extract_cve import extract_cves_from_json, fetch_bulletin_json, get_json_url
from extract_rss import extract_all_rss


def print_header(title: str) -> None:
    print("\n" + "=" * 70)
    print(f" {title}")
    print("=" * 70)


def print_step(step: str) -> None:
    print(f"\n{step}")
    print("-" * 70)


def extract_anssi_id(lien_anssi: str) -> str | None:
    """Extrait l'identifiant CERTFR depuis une URL ANSSI."""
    if not lien_anssi:
        return None

    match = re.search(r"CERTFR-\d{4}-(?:AVI|ALE)-\d+", lien_anssi)

    if match:
        return match.group(0)

    path_parts = [part for part in urlparse(lien_anssi).path.split("/") if part]
    return path_parts[-1] if path_parts else None


def compute_priority_score(cvss: float | None, epss: float | None) -> float | None:
    """
    Calcule un score de priorité entre 0 et 10.
    Formule : 70% CVSS + 30% EPSS ramené sur 10.
    """
    if pd.isna(cvss) and pd.isna(epss):
        return None

    cvss_value = 0 if pd.isna(cvss) else float(cvss)
    epss_value = 0 if pd.isna(epss) else float(epss) * 10

    return round((0.7 * cvss_value) + (0.3 * epss_value), 2)


def classify_cvss(score: float | None) -> str:
    """Transforme un score CVSS en niveau de gravité."""
    if pd.isna(score):
        return "Inconnu"

    if score < 4:
        return "Faible"

    if score < 7:
        return "Moyen"

    if score < 9:
        return "Élevé"

    return "Critique"


def classify_global_risk(priority_score: float | None) -> str:
    """Classe le niveau de risque global."""
    if pd.isna(priority_score):
        return "Inconnu"

    if priority_score >= 8.5:
        return "Critique urgent"

    if priority_score >= 7:
        return "Prioritaire"

    if priority_score >= 5:
        return "À surveiller"

    return "Faible priorité"


def should_alert(row: pd.Series) -> str:
    """Détermine si une alerte doit être générée."""
    cvss = row.get("cvss_score")
    epss = row.get("epss_score")
    bulletin_type = row.get("type_bulletin")

    if pd.notna(cvss) and cvss >= 9:
        return "Oui"

    if pd.notna(epss) and epss >= 0.7:
        return "Oui"

    if bulletin_type == "Alerte":
        return "Oui"

    return "Non"


def alert_reason(row: pd.Series) -> str:
    """Explique la raison de l'alerte."""
    reasons = []

    if pd.notna(row.get("cvss_score")) and row.get("cvss_score") >= 9:
        reasons.append("CVSS critique")

    if pd.notna(row.get("epss_score")) and row.get("epss_score") >= 0.7:
        reasons.append("EPSS élevé")

    if row.get("type_bulletin") == "Alerte":
        reasons.append("Bulletin ANSSI de type Alerte")

    if reasons:
        return ", ".join(reasons)

    return "Critères d'alerte non atteints"


def classify_product_family(product: str | None) -> str:
    """Classe un produit dans une famille simple."""
    if pd.isna(product):
        return "Inconnu"

    product_lower = str(product).lower()

    if any(word in product_lower for word in ["chrome", "firefox", "edge", "safari", "browser"]):
        return "Navigateur"

    if any(word in product_lower for word in ["linux", "windows", "ubuntu", "debian", "red hat", "kernel"]):
        return "Système d'exploitation"

    if any(word in product_lower for word in ["apache", "nginx", "http", "server"]):
        return "Serveur web"

    if any(word in product_lower for word in ["ios", "router", "switch", "firewall", "vpn", "fortinet", "cisco"]):
        return "Réseau / Sécurité"

    if any(word in product_lower for word in ["azure", "aws", "cloud", "kubernetes", "docker"]):
        return "Cloud / Conteneur"

    if any(word in product_lower for word in ["wordpress", "drupal", "joomla"]):
        return "CMS"

    if any(word in product_lower for word in ["office", "outlook", "exchange", "sharepoint"]):
        return "Suite bureautique / Collaboration"

    return "Autre"


def is_sensitive_product(family: str | None) -> str:
    """Indique si la famille de produit est sensible."""
    sensitive_families = {
        "Système d'exploitation",
        "Serveur web",
        "Réseau / Sécurité",
        "Cloud / Conteneur",
        "CMS",
    }

    if family in sensitive_families:
        return "Oui"

    return "Non"


def count_affected_versions(versions: str | None) -> int:
    """Compte le nombre de versions affectées."""
    if pd.isna(versions) or not versions:
        return 0

    return len([v for v in str(versions).split(",") if v.strip()])


def add_temporal_features(df: pd.DataFrame) -> pd.DataFrame:
    """Ajoute les colonnes temporelles."""
    df["date_publication_clean"] = pd.to_datetime(
        df["date_publication"],
        errors="coerce",
        utc=True,
    )

    df["annee_publication"] = df["date_publication_clean"].dt.year
    df["mois_publication"] = df["date_publication_clean"].dt.month
    df["semaine_publication"] = df["date_publication_clean"].dt.isocalendar().week
    df["jour_publication"] = df["date_publication_clean"].dt.day

    return df


def add_risk_features(df: pd.DataFrame) -> pd.DataFrame:
    """Ajoute les colonnes de risque et d'alerte."""
    df["score_priorite"] = df.apply(
        lambda row: compute_priority_score(row.get("cvss_score"), row.get("epss_score")),
        axis=1,
    )

    df["niveau_cvss"] = df["cvss_score"].apply(classify_cvss)
    df["niveau_risque_global"] = df["score_priorite"].apply(classify_global_risk)
    df["alerte_recommandee"] = df.apply(should_alert, axis=1)
    df["raison_alerte"] = df.apply(alert_reason, axis=1)

    return df


def add_product_features(df: pd.DataFrame) -> pd.DataFrame:
    """Ajoute les colonnes liées au produit."""
    df["nombre_versions_affectees"] = df["versions_affectees"].apply(count_affected_versions)
    df["famille_produit"] = df["product"].apply(classify_product_family)
    df["produit_sensible"] = df["famille_produit"].apply(is_sensitive_product)

    return df


def add_ml_features(df: pd.DataFrame) -> pd.DataFrame:
    """Ajoute des variables simples pour le Machine Learning."""
    df["is_critical"] = df["cvss_score"].apply(
        lambda x: 1 if pd.notna(x) and x >= 9 else 0
    )

    df["is_high_epss"] = df["epss_score"].apply(
        lambda x: 1 if pd.notna(x) and x >= 0.7 else 0
    )

    df["is_alert"] = df["type_bulletin"].apply(
        lambda x: 1 if x == "Alerte" else 0
    )

    df["has_cwe"] = df["cwe"].apply(
        lambda x: 0 if pd.isna(x) or x in ["Non disponible", ""] else 1
    )

    df["is_remote"] = df["attack_vector"].apply(
        lambda x: 1 if str(x).upper() == "NETWORK" else 0
    )

    return df


def add_advanced_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ajoute les colonnes avancées :
    A : risque
    D : temps
    F : produit
    H : machine learning
    """
    df = add_temporal_features(df)
    df = add_risk_features(df)
    df = add_product_features(df)
    df = add_ml_features(df)

    return df


def format_final_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Reformate le DataFrame final.

    Les colonnes temporelles détaillées inutiles ont été retirées :
    - Année publication
    - Mois publication
    - Semaine publication
    - Jour publication
    - Ancienneté bulletin en jours
    """

    colonnes_finales = {
        # 1. Informations ANSSI
        "id_anssi": "ID ANSSI",
        "titre_anssi": "Titre ANSSI",
        "type_bulletin": "Type",
        "date_publication": "Date",
        "lien_anssi": "Lien",
        "url_json_anssi": "URL JSON ANSSI",

        # 2. Informations CVE principales
        "cve": "CVE",
        "description_cve": "Description",
        "cwe": "CWE",
        "cwe_description": "Description CWE",

        # 3. Scores principaux
        "cvss_score": "CVSS",
        "base_severity": "Base Severity",
        "epss_score": "EPSS",

        # 4. Produit / éditeur
        "vendor": "Éditeur",
        "product": "Produit",
        "versions_affectees": "Versions affectées",
        "nombre_versions_affectees": "Nombre versions affectées",
        "famille_produit": "Famille produit",
        "produit_sensible": "Produit sensible",

        # 5. Données sur le bulletin
        "nombre_cve_bulletin": "Nombre CVE bulletin",
        "rang_cve_bulletin": "Rang CVE bulletin",

        # 6. Risque et alertes
        "score_priorite": "Score priorité",
        "niveau_cvss": "Niveau CVSS",
        "niveau_risque_global": "Niveau risque global",
        "alerte_recommandee": "Alerte recommandée",
        "raison_alerte": "Raison alerte",

        # 7. Colonnes Machine Learning
        "is_critical": "ML is_critical",
        "is_high_epss": "ML is_high_epss",
        "is_alert": "ML is_alert",
        "has_cwe": "ML has_cwe",
        "is_remote": "ML is_remote",

        # 8. Colonnes CVSS détaillées placées à la fin
        "cvss_version": "Version CVSS",
        "cvss_vector": "Vecteur CVSS",
        "attack_vector": "Attack Vector",
        "attack_complexity": "Attack Complexity",
        "privileges_required": "Privileges Required",
        "user_interaction": "User Interaction",
        "scope": "Scope",
        "confidentiality_impact": "Confidentiality Impact",
        "integrity_impact": "Integrity Impact",
        "availability_impact": "Availability Impact",
    }

    for col in colonnes_finales.keys():
        if col not in df.columns:
            df[col] = None

    df_formatted = df[list(colonnes_finales.keys())].rename(columns=colonnes_finales)

    return df_formatted


def export_to_excel(df: pd.DataFrame, excel_path) -> None:
    """
    Exporte le DataFrame dans un fichier Excel propre :
    - filtres
    - colonnes ajustées
    - première ligne figée
    - en-têtes stylisés
    - retour à la ligne pour les longues cellules
    """

    from openpyxl import load_workbook
    from openpyxl.styles import Font, Alignment, PatternFill
    from openpyxl.worksheet.table import Table, TableStyleInfo

    df.to_excel(
        excel_path,
        index=False,
        sheet_name="Données CVE",
        engine="openpyxl",
    )

    workbook = load_workbook(excel_path)
    worksheet = workbook["Données CVE"]

    worksheet.freeze_panes = "A2"

    header_fill = PatternFill(
        start_color="D9EAF7",
        end_color="D9EAF7",
        fill_type="solid",
    )

    for cell in worksheet[1]:
        cell.font = Font(bold=True)
        cell.fill = header_fill
        cell.alignment = Alignment(
            horizontal="center",
            vertical="center",
            wrap_text=True,
        )

    for column_cells in worksheet.columns:
        column_letter = column_cells[0].column_letter
        header = str(column_cells[0].value)

        if header in [
            "Titre ANSSI",
            "Description",
            "Description CWE",
            "Lien",
            "URL JSON ANSSI",
            "Vecteur CVSS",
        ]:
            worksheet.column_dimensions[column_letter].width = 45

        elif header in [
            "Versions affectées",
            "Produit",
            "Éditeur",
            "Raison alerte",
            "Famille produit",
        ]:
            worksheet.column_dimensions[column_letter].width = 30

        elif header in ["Date"]:
            worksheet.column_dimensions[column_letter].width = 25

        elif header in [
            "ID ANSSI",
            "CVE",
            "Base Severity",
            "Niveau risque global",
            "Alerte recommandée",
        ]:
            worksheet.column_dimensions[column_letter].width = 22

        else:
            worksheet.column_dimensions[column_letter].width = 16

        for cell in column_cells:
            cell.alignment = Alignment(vertical="top", wrap_text=True)

    worksheet.row_dimensions[1].height = 35

    max_row = worksheet.max_row
    max_col = worksheet.max_column
    table_ref = f"A1:{worksheet.cell(row=max_row, column=max_col).coordinate}"

    table = Table(displayName="Table_CVE_ANSSI", ref=table_ref)

    style = TableStyleInfo(
        name="TableStyleMedium9",
        showFirstColumn=False,
        showLastColumn=False,
        showRowStripes=True,
        showColumnStripes=False,
    )

    table.tableStyleInfo = style
    worksheet.add_table(table)

    workbook.save(excel_path)


def build_cve_table(max_bulletins: int | None = None) -> pd.DataFrame:
    """Construit le tableau de base : une ligne = une CVE trouvée dans un bulletin."""

    print_step("[1/4] Extraction des flux RSS ANSSI")

    df_bulletins = extract_all_rss(verbose=False)

    total_bulletins = len(df_bulletins)

    if df_bulletins.empty:
        print("Aucun bulletin RSS récupéré.")
        return pd.DataFrame()

    if max_bulletins is not None:
        df_bulletins = df_bulletins.head(max_bulletins)

    print(f"Total bulletins récupérés : {total_bulletins}")
    print(f"Bulletins traités         : {len(df_bulletins)}")

    rows = []

    print_step("[2/4] Extraction des CVE depuis les JSON ANSSI")

    for idx, bulletin in enumerate(df_bulletins.itertuples(index=False), start=1):
        lien = getattr(bulletin, "lien_anssi")
        titre = getattr(bulletin, "titre_anssi")
        type_bulletin = getattr(bulletin, "type_bulletin")
        id_anssi = extract_anssi_id(lien)
        url_json = get_json_url(lien)

        data = fetch_bulletin_json(lien)
        cves = extract_cves_from_json(data)
        nb_cves_bulletin = len(cves)

        print(
            f"[{idx:02d}] {id_anssi} | {type_bulletin:<6} | "
            f"{nb_cves_bulletin:>4} CVE | {titre[:60]}"
        )

        for rang, cve in enumerate(cves, start=1):
            rows.append(
                {
                    "id_anssi": id_anssi,
                    "titre_anssi": titre,
                    "description_anssi": getattr(bulletin, "description_anssi"),
                    "type_bulletin": type_bulletin,
                    "date_publication": getattr(bulletin, "date_publication"),
                    "lien_anssi": lien,
                    "url_json_anssi": url_json,
                    "nombre_cve_bulletin": nb_cves_bulletin,
                    "rang_cve_bulletin": rang,
                    "cve": cve,
                }
            )

    df_cves = pd.DataFrame(rows)

    print("\nRésumé CVE")
    print(f"  Lignes CVE         : {len(df_cves)}")

    if not df_cves.empty:
        print(f"  CVE uniques        : {df_cves['cve'].nunique()}")
        print(f"  Bulletins avec CVE : {df_cves['id_anssi'].nunique()}")

    return df_cves


def enrich_unique_cves(
    cves: list[str],
    max_cves: int | None = None,
) -> pd.DataFrame:
    """Enrichit une liste unique de CVE avec MITRE et EPSS."""

    total_cves = len(cves)

    if max_cves is not None:
        cves = cves[:max_cves]

    print_step("[3/4] Enrichissement MITRE / EPSS")
    print(f"CVE détectées       : {total_cves}")
    print(f"CVE à enrichir      : {len(cves)}")

    if max_cves is not None and max_cves < total_cves:
        print(f"Mode test           : enrichissement limité à {max_cves} CVE")

    enrichment_rows = []

    for index, cve in enumerate(cves, start=1):
        print(f"[{index:03d}/{len(cves):03d}] {cve}")

        mitre_info = enrich_cve_mitre(cve)
        mitre_info["epss_score"] = enrich_cve_epss(cve)

        enrichment_rows.append(mitre_info)

    return pd.DataFrame(enrichment_rows)


def build_dataset(
    max_bulletins: int | None = None,
    skip_enrichment: bool = False,
    max_cves: int | None = None,
) -> pd.DataFrame:
    """Pipeline complet de construction du dataset final."""

    print_header("PIPELINE ANSSI - CVE")

    FINAL_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)

    df_cves = build_cve_table(max_bulletins=max_bulletins)

    processed_cves_path = PROCESSED_DIR / "bulletins_cves.csv"
    df_cves.to_csv(processed_cves_path, index=False, encoding="utf-8-sig")

    if df_cves.empty:
        print("\nAucune CVE trouvée. Fin du programme.")
        return df_cves

    if skip_enrichment:
        print_step("[3/4] Enrichissement ignoré")

        df_cves_formatted = format_final_dataframe(df_cves)
        df_cves_formatted.to_csv(FINAL_CSV_PATH, index=False, encoding="utf-8-sig")

        excel_path = FINAL_DIR / "donnees_anssi_cve_enrichies.xlsx"
        export_to_excel(df_cves_formatted, excel_path)

        print_step("[4/4] Export final")
        print(f"CSV créé     : {FINAL_CSV_PATH}")
        print(f"Excel créé   : {excel_path}")
        print(f"Lignes       : {len(df_cves_formatted)}")
        print(f"Colonnes     : {len(df_cves_formatted.columns)}")

        return df_cves_formatted

    unique_cves = sorted(df_cves["cve"].dropna().unique())

    df_enrichment = enrich_unique_cves(
        unique_cves,
        max_cves=max_cves,
    )

    enrichment_path = PROCESSED_DIR / "enrichissement_cves.csv"
    df_enrichment.to_csv(enrichment_path, index=False, encoding="utf-8-sig")

    print_step("[4/4] Fusion et export final")

    df_final = df_cves.merge(df_enrichment, on="cve", how="left")

    df_final = add_advanced_features(df_final)

    df_final_formatted = format_final_dataframe(df_final)

    df_final_formatted.to_csv(FINAL_CSV_PATH, index=False, encoding="utf-8-sig")

    excel_path = FINAL_DIR / "donnees_anssi_cve_enrichies.xlsx"
    export_to_excel(df_final_formatted, excel_path)

    print(f"Fichier CVE brut    : {processed_cves_path}")
    print(f"Fichier enrichi     : {enrichment_path}")
    print(f"CSV final           : {FINAL_CSV_PATH}")
    print(f"Excel final         : {excel_path}")
    print(f"Lignes finales      : {len(df_final_formatted)}")
    print(f"Colonnes finales    : {len(df_final_formatted.columns)}")
    print(f"CVE uniques         : {df_final_formatted['CVE'].nunique()}")

    if max_cves is not None:
        nb_enrichies = df_enrichment["cve"].nunique() if "cve" in df_enrichment.columns else 0
        print(f"CVE enrichies       : {nb_enrichies}")
        print("Note                : les CVE non enrichies ont des valeurs MITRE/EPSS vides.")

    print("\nPipeline terminé avec succès.")

    return df_final_formatted


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Construit le dataset ANSSI CVE consolidé et enrichi."
    )

    parser.add_argument(
        "--max-bulletins",
        type=int,
        default=3,
        help="Nombre maximum de bulletins à traiter. Utiliser -1 pour tout traiter.",
    )

    parser.add_argument(
        "--skip-enrichment",
        action="store_true",
        help="Ignore l'enrichissement MITRE/EPSS pour générer rapidement un CSV de base.",
    )

    parser.add_argument(
        "--max-cves",
        type=int,
        default=None,
        help="Nombre maximum de CVE à enrichir pour accélérer les tests.",
    )

    args = parser.parse_args()

    max_bulletins = None if args.max_bulletins == -1 else args.max_bulletins

    build_dataset(
        max_bulletins=max_bulletins,
        skip_enrichment=args.skip_enrichment,
        max_cves=args.max_cves,
    )