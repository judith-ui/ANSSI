"""Chargement des données depuis les fichiers locaux pré-téléchargés."""

import json
from pathlib import Path
from typing import Any

from config import LOCAL_AVIS_DIR, LOCAL_ALERTES_DIR, LOCAL_MITRE_DIR, LOCAL_FIRST_DIR


def load_local_bulletin(bulletin_id: str) -> dict[str, Any] | None:
    """
    Charge un bulletin ANSSI depuis les fichiers locaux.
    Cherche d'abord dans les avis, puis dans les alertes.
    """
    for folder in [LOCAL_AVIS_DIR, LOCAL_ALERTES_DIR]:
        path = Path(folder) / bulletin_id
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)

    print(f"Bulletin local introuvable : {bulletin_id}")
    return None


def load_local_mitre(cve_id: str) -> dict[str, Any] | None:
    """Charge les données MITRE depuis les fichiers locaux."""
    path = Path(LOCAL_MITRE_DIR) / cve_id
    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    print(f"MITRE local introuvable : {cve_id}")
    return None


def load_local_epss(cve_id: str) -> float | None:
    """Charge le score EPSS depuis les fichiers locaux."""
    path = Path(LOCAL_FIRST_DIR) / cve_id
    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        epss_data = data.get("data", [])
        if epss_data:
            return float(epss_data[0].get("epss"))

    print(f"EPSS local introuvable : {cve_id}")
    return None


def list_local_bulletins() -> list[str]:
    """Retourne la liste de tous les IDs de bulletins disponibles en local."""
    ids = []
    for folder in [LOCAL_AVIS_DIR, LOCAL_ALERTES_DIR]:
        folder_path = Path(folder)
        if folder_path.exists():
            ids += [f.name for f in folder_path.iterdir() if f.is_file()]
    return sorted(ids)