"""Configuration générale du projet."""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
FINAL_DIR = DATA_DIR / "final"
OUTPUTS_DIR = BASE_DIR / "outputs"
FIGURES_DIR = OUTPUTS_DIR / "figures"
EMAILS_DIR = OUTPUTS_DIR / "emails"

RSS_AVIS_URL = "https://cert.ssi.gouv.fr/avis/feed/"
RSS_ALERTES_URL = "https://cert.ssi.gouv.fr/alerte/feed/"

REQUEST_TIMEOUT = 15
REQUEST_DELAY_SECONDS = 2

FINAL_CSV_PATH = FINAL_DIR / "donnees_anssi_cve_enrichies.csv"

# ---------------------------------------------------------------------------
# Mode données locales
# ---------------------------------------------------------------------------
# Mettre USE_LOCAL_DATA = True pour travailler avec les fichiers pré-téléchargés
# (évite les requêtes réseau répétées pendant le développement).
# Les dossiers doivent exister et contenir les fichiers JSON téléchargés.
USE_LOCAL_DATA = False

LOCAL_DATA_DIR = BASE_DIR / "data" / "local"
LOCAL_AVIS_DIR = LOCAL_DATA_DIR / "avis"
LOCAL_ALERTES_DIR = LOCAL_DATA_DIR / "alertes"
LOCAL_MITRE_DIR = LOCAL_DATA_DIR / "mitre"
LOCAL_FIRST_DIR = LOCAL_DATA_DIR / "first"
