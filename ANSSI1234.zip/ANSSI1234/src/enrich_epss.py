"""Enrichissement des CVE avec l'API EPSS FIRST."""

import time

import requests

from config import REQUEST_DELAY_SECONDS, REQUEST_TIMEOUT, USE_LOCAL_DATA
from local_loader import load_local_epss


def enrich_cve_epss(cve_id: str) -> float | None:
    """Récupère le score EPSS d'une CVE (local ou API)."""

    # Mode données locales
    if USE_LOCAL_DATA:
        return load_local_epss(cve_id)

    url = f"https://api.first.org/data/v1/epss?cve={cve_id}"

    try:
        response = requests.get(url, timeout=REQUEST_TIMEOUT)
        response.raise_for_status()
        data = response.json()

        epss_data = data.get("data", [])
        if epss_data:
            return float(epss_data[0].get("epss"))

    except Exception as exc:
        print(f"Erreur EPSS pour {cve_id}: {exc}")

    finally:
        # Délai uniquement en mode API
        if not USE_LOCAL_DATA:
            time.sleep(REQUEST_DELAY_SECONDS)

    return None
